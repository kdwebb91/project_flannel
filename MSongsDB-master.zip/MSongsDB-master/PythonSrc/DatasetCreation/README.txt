/PythonSrc/DatasetCreation/README.txt

     by T. Bertin-Mahieux (2010) Columbia University
        tb2332@columbia.edu

Contains the python code and some text files used to
create (=download!) the Million Song Dataset.
