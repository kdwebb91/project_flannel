/PythonSrc/MBrainzDB/README.txt
   by T. Bertin-Mahieux (2010) Columbia University
      tb2332@columbia.edu

Code to call the music brainz database that has been installed
locally.

This is not an extensive code to access all fields in the database!
The main goal is to provide a release year and some musicbrainz id
to the Million Song dataset.

The database is postgresql, the two database names are:
musicbrainz_db and musicbrainz_db_raw.
The user is 'gordon' with password 'gordon'.

For details on the structure of the MusicBrainz dataset, see:
musicbrainz.org
