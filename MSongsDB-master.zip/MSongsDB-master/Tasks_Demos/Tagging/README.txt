/Tasks_Demos/Tagging/README.txt
    by T. Bertin-Mahieux (2010) Columbia University
       tb2332@columbia.edu


This folder contains every code related to automatic tagging using
Echo Nest artist terms.

A SPLIT BETWEEN TRAIN AND TEST ARTISTS HAS BEEN MADE.
Please report results using this split, so they are easily comparable.
File are: artists_train.txt and artists_test.txt

We based the split on the 300 most used terms, the list is provided,
ordered by frequency: top_terms.txt
