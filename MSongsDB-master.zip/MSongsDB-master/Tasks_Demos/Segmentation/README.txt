Tasks/Segmentation/README.txt

T. Bertin-Mahieux (2010) Columbia University
tb2332@columbia.edu
Part of the Million Song Dataset, a collaboration
between LabROSA and the Echo Nest

This folder contains code to perform segmentation
on the Million Song dataset data.
Out starting point is the code from Luke Barrington
at UCSD:
http://cosmal.ucsd.edu/cal/projects/segment/
