tasks/NamesAnalysis/README.txt
   by T. Bertin-Mahieux (2010) Columbia University
      tb2332@columbia.edu

This folder / task deals with metadata like artist names,
release names, song names.

We extract useful information like the list of all artists in
the dataset, the list of all releases, etc.

Some results are interesting on their own, e.g. the average
artist name length, but mostly this is code that could be reuse
for other things.
For instance, the list of all artists is important to split
the dataset into train / test for a tag recognition task.
