/Tasks_Demos/CoverSongs/README.txt

    by T. Bertin-Mahieux (2010) Columbia University
       tb2332@columbia.edu

This folder contains the SecondHandSongs dataset!
http://labrosa.ee.columbia.edu/millionsong/secondhand

Also, it will eventually contain helper code to deal with covers,
and even benchmark algorithms.

