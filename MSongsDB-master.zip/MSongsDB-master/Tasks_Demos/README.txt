Tasks/README.txt

T. Bertin-Mahieux (2010) Columbia University
tb2332@columbia.edu
Part of the Million Song Dataset, a collaboration
between LabROSA and the Echo Nest

This folder contains code to get people started on
specific tasks.

See each task for details, plus the webpage.
Most of it is in python, and it might rely on external
libraries.

If you have code that you want to be included here, or
more simply have a link on the Million Song Dataset
webpage, please send me an email!
